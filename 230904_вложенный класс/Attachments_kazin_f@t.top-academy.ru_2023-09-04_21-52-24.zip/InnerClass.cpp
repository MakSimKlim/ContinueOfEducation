#include <iostream>
using namespace std;

class A
{
public:
	A()
	{
		cout << "This is global A." << endl;
	}
};

class B
{
	string value;

	class A {		
	public:
		static int amount_of_a;
		int value;
		A();
		A(int v);

		friend A operator+(A p1, A p2)
		{
			return A{ p1.value + p2.value };
		}

		void refB(B& b1)
		{
			b1.getValue();
		}
	};

	class C;
	C* c;

	class R;
	class F
	{
		R* r;
	};

	class R
	{
		F* f;
	};
public:
	B()
	{
		value = "";
		A obj;
	}

	B(string v) : value{ v } {}

	string getValue() { return value; }
};

int B::A::amount_of_a{ 0 };

B::A::A()
{
	value = 0;
}

B::A::A(int val) : value{ val } {};

class B::C
{
public:
	char value;
	C() { value = '\0'; }
	C(string s) : value{ s[0] } {}
	C(char c) : value{ c } {}
};

int main1()
{
	B b;
	A a;
	return 0;
}